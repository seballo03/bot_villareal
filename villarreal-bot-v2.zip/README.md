# 🤖 Bot Villarreal — Vendedor 24/7 WhatsApp

Bot de WhatsApp con menús interactivos para gestión de solicitudes de crédito, catálogo de productos y selección de tienda.

---

## 📁 Estructura

```
whatsapp-bot/
├── index.js        ← Lógica principal del bot
├── .env            ← Credenciales (NO subir a GitHub)
├── package.json
└── README.md
```

---

## 🔑 Configuración (.env)

```env
PHONE_NUMBER_ID=1102021796327685
ACCESS_TOKEN=tu_token_aqui
WHATSAPP_BUSINESS_ACCOUNT_ID=tu_waba_id
VERIFY_TOKEN=villarreal_bot_2024
PORT=3000
```

---

## 🚀 Instalación y arranque

```bash
npm install
node index.js
```

---

## 🌐 Despliegue (necesitas URL pública)

### Opción A — Railway (recomendado, gratis)
1. Crear cuenta en railway.app
2. Subir este proyecto
3. Railway genera la URL pública

### Opción B — Render
1. Crear cuenta en render.com
2. New Web Service → conectar repositorio

### Opción C — ngrok (solo pruebas locales)
```bash
ngrok http 3000
```

---

## ⚙️ Configurar Webhook en Meta

1. Ve a **developers.facebook.com → Tu App → WhatsApp → Configuración**
2. En "URL de devolución de llamada" pon: `https://TU-URL/webhook`
3. En "Token de verificación" pon: `villarreal_bot_2024`
4. Suscríbete a: `messages`

---

## 🗺️ Flujo del bot

```
BIENVENIDA
    ├── 📋 Iniciar solicitud
    │       ├── ⭐ Cliente preferente
    │       └── 🆕 Cliente nuevo
    │               ↓
    │           Nombre → Teléfono → Correo
    │               ↓
    │           📄 INER → Estado de cuenta → Comprobante → Selfie
    │               ↓
    │           📍 Seleccionar tienda (10 sucursales)
    │               ↓
    │           ✅ Confirmación → Folio generado
    │
    ├── 🛍️ Ver catálogo
    │       ├── ❄️ Climas
    │       ├── 🛋️ Muebles
    │       └── 🍽️ Línea Blanca
    │
    └── ❓ Preguntas frecuentes
            ├── ¿Cómo aplico?
            ├── ¿Cuánto tarda?
            ├── ¿Qué documentos?
            ├── ¿Cuál es mi límite?
            └── ¿Cómo pago?
```

---

## 📌 Próximos pasos

- [ ] Obtener WHATSAPP_BUSINESS_ACCOUNT_ID
- [ ] Agregar coordenadas reales de las 10 tiendas
- [ ] Conectar con CRM o base de datos
- [ ] Notificación por email a la tienda al recibir solicitud
- [ ] Agregar más categorías al catálogo
- [ ] Subir a servidor con URL pública
